Sanskript cross-platform installer bundle (linux)
Run the launcher script after extracting; requires Python on PATH.
